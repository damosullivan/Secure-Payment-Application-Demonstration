<?php

include_once("../include/config.php");
include_once(INCLUDE_DIR . "/" . "htmlFunctions.php");
include_once(INCLUDE_DIR . "/" . "mitigate.php");
include_once(INCLUDE_DIR . "/" . "FYP_functions.php");

session_start();

$mysqli = new mysqli( DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE );#Used till the end

$loggedIn = false;

outputHeader($loggedIn, $mysqli);

?>

<?php
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$pass = filter_input(INPUT_POST, 'pass', FILTER_SANITIZE_STRING);
  #$pass = hashPass($pass); // cant do here as I do not have the salt or iterator yet


#GET RID OF ME!
$email = $_POST['email'];




$cleanEmail = mitigate($mysqli, 'realEscapeString', $email);


$statement = $mysqli->prepare("SELECT userId, fName, passwordHash, image FROM FYP.user_info WHERE email = ? LIMIT 1");
$statement->bind_param('s', $cleanEmail);
$statement->execute();
$statement->store_result();


//$query = $mysqli->query($sql);

if(mitigateBool($mysqli, "preparedStatement")){
//if(false){


	if ($statement->num_rows == 1) {
		$statement->bind_result($user_id, $fName, $storedPass, $image);
		$statement->fetch();

		list($salt, $iterator, $storedHashedPassword) = explode(":", $storedPass);

		if($storedPass == hashPass($pass, $salt, $iterator) ){
			echo "Logged in";

			$user_browser = $_SERVER['HTTP_USER_AGENT'];
			$_SESSION['auth']['user_id'] = $user_id;
	      // XSS protection as we might print this value
			$username = preg_replace("/[^a-zA-Z0-9_\-]+/", "", $fName);
			$_SESSION['auth']['fName'] = $fName;


			$_SESSION['auth']['imgUrl'] = $image;

	      $user_browser = $_SERVER['HTTP_USER_AGENT'];#can be checked evertime
	      $_SESSION['auth']['login_string'] = hash('sha512', $storedPass . $user_browser);#may not use!!
	      
	      //session_regenerate_id(TRUE);
	      mitigate($mysqli, "regenerateSessionId");

	     /*
	      echo "<ul>";
	      echo "<li>".$_SESSION['auth']['user_id']."</li>";
	      echo "<li>".$_SESSION['auth']['fName']."</li>";
	      echo "<li>".$_SESSION['auth']['login_string']."</li>";
	      echo "</ul>";
	     */ 

	      header( 'Location: home.php' ) ;
	      
	  }else{
	      //wrong password
	  	echo "wrong password";
	  	header( 'Location: index.php?error=wrong password' ) ;
	  }

	}else{
	    //Invalid Email Address
		echo "Wrong email";
		header( 'Location: index.php?error=wrong email' ) ;
	}
}else{#not prepared statements!!!
	$sql = "SELECT userId, fName, passwordHash, image FROM FYP.user_info WHERE email = '" . $cleanEmail . "' LIMIT 1";

	$result = $mysqli->query($sql);

	if ($result->num_rows > 0) {
		$firstRow = $result->fetch_assoc();

		#var_dump($firstRow);
		#die();

		$user_id = $firstRow['userId'];
		$fName = $firstRow['fName'];
		$storedPass = $firstRow['passwordHash'];
		$image = $firstRow['image'];

		list($salt, $iterator, $storedHashedPassword) = explode(":", $storedPass);
		if($storedPass == hashPass($pass, $salt, $iterator) ){
			echo "Logged in";

			$user_browser = $_SERVER['HTTP_USER_AGENT'];
			$_SESSION['auth']['user_id'] = $user_id;
	      // XSS protection as we might print this value
			$username = preg_replace("/[^a-zA-Z0-9_\-]+/", "", $fName);
			$_SESSION['auth']['fName'] = $fName;


			$_SESSION['auth']['imgUrl'] = $image;

	      $user_browser = $_SERVER['HTTP_USER_AGENT'];#can be checked evertime
	      $_SESSION['auth']['login_string'] = hash('sha512', $storedPass . $user_browser);#may not use!!
	      
	      //session_regenerate_id(TRUE);
	      mitigate($mysqli, "regenerateSessionId");

	     /*
	      echo "<ul>";
	      echo "<li>".$_SESSION['auth']['user_id']."</li>";
	      echo "<li>".$_SESSION['auth']['fName']."</li>";
	      echo "<li>".$_SESSION['auth']['login_string']."</li>";
	      echo "</ul>";
	     */ 

	      header( 'Location: home.php' ) ;

	  }else{
	      //wrong password
	  	echo "wrong password";
	  	header( 'Location: index.php?error=wrong password' ) ;
	  }

	}else{
	    //Invalid Email Address
		echo "Wrong email";
		header( 'Location: index.php?error=wrong email' ) ;
	}
}
/**
      $filter_email = filter_var( $_GET['email'], FILTER_VALIDATE_EMAIL );				
      $cleanemail = $mysqli->real_escape_string($filter_email);
      #$cleanemail = $filter_email;
      
      
      $statement = $mysqli->prepare("SELECT userId, email, passwordHash FROM FYP.user_info WHERE email = ?");
      $statement->bind_param('s', $cleanemail);
      $statement->execute();
      $statement->bind_result($storedUserId, $storedemail, $storedPass);
      if($statement->fetch()){
	if( comaprePassword($storedPass, $pass) ){
	  session_start();
	  $_SESSION['inThere'] = 1;
	  $_SESSION['userId'] = $storedUserId;
	  header( 'Location: home.php' ) ;

	 }else{
	  header( 'Location: index.php?error=password_wrong' ) ;
	 }
	 
      }
      $statement->close();

*/	      
      ?>    
      <?php
      outputFooter($loggedIn);
      $mysqli->close();
      ?>
