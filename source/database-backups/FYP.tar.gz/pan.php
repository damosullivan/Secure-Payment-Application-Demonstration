<html>
<head>
</head>
<body>
<h1>Storing PAN(Primary Account Number)</h1>

<?php
	$pan = "4929998893984372";
	$key = getKey(1);
	echo "<p>PAN (Note: This is fake!): {$pan}.</p>";
	#echo "<p>MAX: ".PHP_INT_MAX.".</p>";
	
	#hash algorithm
	$algo = "sha256";
	$hash = hash($algo ,$pan); #[, bool $raw_output = false ] )
	echo "<p>hash: {$hash}</p>";
	
	#encrypt
	$Pass = $key;
	$Clear = $pan;        

	$crypted = fnEncrypt($Clear, $Pass);
	echo "Encrypred: ".$crypted."</br>";

	$newClear = fnDecrypt($crypted, $Pass);
	echo "Decrypred: ".$newClear."</br>";   
	
	
	#truncation
	$truncation = smarty_modifier_stars($pan, 4);# % 10000;
	echo "<p>Truncate: {$truncation}</p>";
	
	
	function smarty_modifier_stars($string, $suffix = 0, $char = '*'){
		$_prefix_len = strlen($string) - $suffix;
		if($_prefix_len > 0) {
			return str_repeat($char, $_prefix_len) . substr($string, - $suffix);
		} else {
			return $string;
		}
	}
	
	function fnEncrypt($sValue, $sSecretKey)
	{
		return rtrim(
			base64_encode(
				mcrypt_encrypt(
					MCRYPT_RIJNDAEL_256,
					$sSecretKey, $sValue, 
					MCRYPT_MODE_ECB, 
					mcrypt_create_iv(
						mcrypt_get_iv_size(
							MCRYPT_RIJNDAEL_256, 
							MCRYPT_MODE_ECB
						), 
						MCRYPT_RAND)
					)
				), "\0"
			);
	}

	function fnDecrypt($sValue, $sSecretKey)
	{
		return rtrim(
			mcrypt_decrypt(
				MCRYPT_RIJNDAEL_256, 
				$sSecretKey, 
				base64_decode($sValue), 
				MCRYPT_MODE_ECB,
				mcrypt_create_iv(
					mcrypt_get_iv_size(
						MCRYPT_RIJNDAEL_256,
						MCRYPT_MODE_ECB
					), 
					MCRYPT_RAND
				)
			), "\0"
		);
	}
	
	function getKey($someValue){
		$keyStoredAt = ".";
		$keyName = "encryption_key.txt";
		$key = readfile($keyStoredAt . "/" . $keyName);
		return $key;
	}

?>

</body>
</html>