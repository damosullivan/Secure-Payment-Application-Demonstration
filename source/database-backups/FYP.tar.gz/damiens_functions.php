<?php
	//require_once('output_functions.php');
	/*
	Calculate Age
	With this function you can calculate the age of a person

	calculate years of age (input string: YYYY-MM-DD)
	*/

	function birthday ($birthday)
	{
		list($year,$month,$day) = explode("-",$birthday);

		$year_diff = date("Y") - $year;
		$month_diff = date("m") - $month;
		$day_diff = date("d") - $day;
		if ($month_diff < 0)
			{
			$year_diff--;
			}
			elseif (($month_diff==0) && ($day_diff < 0))
			{
			$year_diff--;
			}
		return $year_diff;
	}
	 
	/*
	A random person generator!!!
	Generates a random person.

	NO INPUT!
	*/
	function rand_person ()
	{
			$sql = "SELECT * FROM users;";
			$dbresult = mysql_query( $sql );
			
			$num_rows = mysql_num_rows($dbresult);
			$rand = rand(1, $num_rows);
			$sql = "SELECT username FROM users WHERE id = '{$rand}';";
			$dbresult = mysql_query( $sql );
			if ( ! $dbresult )
			{
				output_footer( 'Damien Web' );
				echo 'Error in query ' . mysql_error();
			}
			while ( $row = mysql_fetch_assoc($dbresult) ) 
			{
				foreach($row as $line => $val)
				{
					return $val;
				}
			}
			mysql_free_result( $dbresult );
	
	}

	
	/*
	Calculate no of days
	With this function you can calculate the no of days from the start ... i think!

	(input string: 'YYYY-MM-DD')
	*/
	
	function date_to_days ( $date )
	{
		list($year,$month,$day) = explode("-",$date);
		
		$days = (int)(($year * 365) + ($month * 30) + $day) ;
		
		return $days;
	}
	
	
	/*
	Checks if username and matching id is in database
	outputs true or false

	(input string: '')
	*/
	
	function proof()
	{
		$dbconnection = connect_to_database( 'localhost', 'dos4', 'mejohvoo', '2013_dos4' );
		
		if( isset($_SESSION['18authenticated']) )
		{
			$sql = "SELECT id, username FROM users WHERE id = '{$_SESSION['id']}' AND username = '{$_SESSION['username']}';";
			$dbresult = mysql_query( $sql );
			if ( ! $dbresult )
			{
				mysql_close( $dbconnection );
				return false;			
			}
			else
			{
				while ( $row = mysql_fetch_assoc($dbresult) ) 
				{
					foreach($row as $line => $val)
					{
						$user[$line] = $val;
					}
				}
				if( $user['id'] == $_SESSION['id'] && $user['username'] == $_SESSION['username'] )
				{
					mysql_close( $dbconnection );
					return true;
				}
				else
				{
					mysql_close( $dbconnection );
					return false;		
				}
			
			}
		}
		else
		{
			mysql_close( $dbconnection );
			return false;		
		}
	
	}

	function output_logged_in_header( $uplevel )
	{
		if( $uplevel )
		{
			
			echo 
				'<?xml version="1.0" encoding="UTF-8"?>
				 <!DOCTYPE html 
				  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
				  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
				 <head>';
			echo "<title>Eighteen</title>";
			echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"../stylesheet.css\" />";
			echo "<link rel=\"shortcut icon\" href=\"favicon.ico\" />";
			echo 
				'</head>
				 <body>';
			echo '<div id="wrapper" >';
			echo '<div id="top" >';
			echo "<h1>Eighteen</h1>";
			echo '<p id="login_status" ><a href="../home" >' . $_SESSION['username'] . '</a> | <a href="../account/logout.php" >Logout?</a></p>
				<ul>
				<li><a href="../home" >Home</a></li>
				<li><a href="../profile?username=' . $_SESSION['username'] . '" >Profile</a></li>
				<li><a href="../people" >People</a></li>
				<li></li>
				</ul>';
			echo '</div>';//end ot div top!
			echo '<div id="main" >';
		}
		else
		{
			echo 
				'<?xml version="1.0" encoding="UTF-8"?>
				 <!DOCTYPE html 
				  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
				  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
				 <head>';
			echo "<title>Eighteen</title>";
			echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"stylesheet.css\" />";
			echo "<link rel=\"shortcut icon\" href=\"favicon.ico\" />";
			echo 
				'</head>
				 <body>';
			echo '<div id="wrapper" >';
			echo '<div id="top" >';
			echo "<h1>Eighteen</h1>";
			echo '
				<p id="login_status" ><a href="home" >' . $_SESSION['username'] . '</a> | <a href="account/logout.php" >Logout?</a></p>
				<ul>
				<li><a href="home" >Home</a></li>
				<li><a href="profile?username=' . $_SESSION['username'] . '" >Profile</a></li>
				<li><a href="people" >People</a></li>
				</ul>';
			echo '</div>';//end ot div top!
			echo '<div id="main" >';
		}
	}

	function output_logged_out_header( $uplevel )
	{
		if($uplevel)
		{
			echo 
				'<?xml version="1.0" encoding="UTF-8"?>
				 <!DOCTYPE html 
				  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
				  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
				 <head>';
			echo "<title>Eighteen</title>";
			echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"../stylesheet.css\" />";
			echo "<link rel=\"shortcut icon\" href=\"favicon.ico\" />";
			echo 
				'</head>
				 <body>';
			echo '<div id="wrapper" >';
			echo '<div id="top" >';
			echo "<h1>Eighteen</h1>";
			echo '<p id="login_status" ><a href="../account/sign-up.php" >Sign-up</a> | <a href="../account/login.php" >Login?</a></p>
				<ul>
				<li><a href="../index.php" >Home</a></li>
				<li><a href="../profile" >Profile</a></li>
				<li><a href="../people" >People</a></li>
				</ul>';
			echo '</div>';//end ot div top!
			echo '<div id="main" >';
		}
		else
		{
			echo 
				'<?xml version="1.0" encoding="UTF-8"?>
				 <!DOCTYPE html 
				  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
				  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
				 <head>';
			echo "<title>Eighteen</title>";
			echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"stylesheet.css\" />";
			echo "<link rel=\"shortcut icon\" href=\"favicon.ico\" />";
			echo 
				'</head>
				 <body>';
			echo '<div id="wrapper" >';
			echo '<div id="top" >';
			echo "<h1>Eighteen</h1>";
			echo '<p id="login_status" ><a href="account/sign-up.php" >Sign-up</a> | <a href="account/login.php" >Login?</a></p>
				<ul>
				<li><a href="" >Home</a></li>
				<li><a href="account/login.php" >Profile</a></li>
				<li><a href="people" >People</a></li>
				</ul>';
			echo '</div>';//end of div top!
			echo '<div id="main" >';
		}
		return true;
	}
	
	function output_end()
	{
		echo '</div>';// end of main div!
		echo '</div>';// end of wrapper!
		output_footer( 'Damien Web' );
	}
	
	
?>