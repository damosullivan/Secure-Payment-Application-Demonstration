<?php

function outputHeader($loggedIn, $mysqli=null){
	echo <<<HTML
	<?xml version="1.0" encoding="UTF-8"?>
	<!DOCTYPE html 
	PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Secure Payment Application Demonstration</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link type="text/css" href="../stylesheet.css" rel="stylesheet" />
		<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link rel="shortcut icon" href="favicon.ico" />
HTML;
		echo mitigate($mysqli, "frameBlock");
		echo mitigate($mysqli, "frameBlockingLegacy"); 
		echo <<<HTML

	</head>
HTML;

if(mitigateBool($mysqli, 'dashboard')){
	echo '<body onLoad="trythis(0);" >';
}else{
	echo '<body>';
}

	
	echo <<<HTML
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="../bootstrap/js/bootstrap.min.js"></script>
HTML;
    #
		echo '<div id="container" >';

		if($loggedIn){
			echo <<<HTML
			<div class="header">

				<ul class="nav nav-pills pull-right">
					<li class="active"><a href="home.php">Home</a></li>
					<li><a href="cards.php">Cards</a></li>
					<li><a href="transactions.php">Transactions</a></li>
					<li><a href="logout.php" >Log out</a></li>
				</ul>
				<h3 class="text-muted">Security Application<br/>Demonstration</h3>

			</div>
HTML;
		}else{
			echo <<<HTML
			<div class="header">
				<form class="navbar-form navbar-right" role="form" action="login.php" method="post" >
					<div class="form-group">
						<input type="text" placeholder="Email" name="email" class="form-control">
					</div>
					<div class="form-group">
						<input type="password" placeholder="Password" name="pass" class="form-control">
					</div>
					<button type="submit" class="btn btn-success">Sign in</button>
				</form>
				<ul class="nav nav-pills pull-right">


				</ul>
				<h3 class="text-muted"><br/><br/></h3>

			</div>
HTML;
		}


#return true;
	}

	function outputFooter($loggedIn, $dashboard = true){
		echo "</div><!-- END OF 'container' DIV -->";

		if($dashboard){
			echo <<<HTML
			<!--
			<button class="btn btn-lg btn-success" id="dashboard_toggle" onclick="$('#dashboard_iframe').toggle();">Dashboard</button>
			<div id="dashboard" >
				<!--<iframe id="dashboard_iframe" src="../Dashboard/dash2.php" widht="300px" onLoad="document.getElementById(id).height= (document.getElementById('dashboard_iframe').contentWindow.document.body.scrollHeight) + 'px'" ></iframe>-->
				
		
			


			<div id="slide" style="right: -300px; top: 0px; width: 300px;">
				<div id="control">
					
					<iframe id="dashboard_iframe" seamless src="../Dashboard/dash5.php" widht="300px" height="100%" alllowtransparence="false" ></iframe>

					<button class="btn btn-lg btn-success" onclick="trythis();" id="dashboard_toggle" >Dashboard</button>

					<script type="text/javascript">
						function trythis(newTime) {
							var time = 500;
							if(newTime != null){
								time = newTime;
							}

							if( $.trim( $('#slide').css('right') ) != '0px'){ 
								$('#slide').animate({right:"0px"},time);
								//enable  
								$.get('../Dashboard/enable.php?enable[]=dashboard', function(data) {
									
								});
							}else{
								$('#slide').animate({right:"-300px"},time); 
								//disable
								$.get('../Dashboard/enable.php?disable[]=dashboard', function(data) {
									
								});
							}
						}
					</script>

				</div>
			</div>







HTML;
		}

		echo <<<HTML
		<div class="footer text-center">
			<p>&copy; Damien 2014</p>
		</div>
	</body>
	</html>
HTML;

#return true;
}


?>