<?php
/**
 * These are the database login details
 */  
define("DB_HOST", "localhost");     // The host you want to connect to.
define("DB_USER", "dos4");    // The database username. 
define("DB_PASSWORD", "Password123");    // The database password. 
define("DB_DATABASE", "FYP");    // The database name.

define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");

define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!

define("DEBUG", FALSE);
define("INCLUDE_DIR", "/home/damien/public_html/FYP/include");
define("IMG_DIR", "/home/damien/public_html/FYP/Images");

define("URL_ADDRESS", "https://localhost/");

define("PROTOTYPE", "Prototype5");


?>