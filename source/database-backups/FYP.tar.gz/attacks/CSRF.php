<<!DOCTYPE html>
<html>
<head>
	<title>
		CSRF Attack
	</title>
</head>
<body>
<h1>CSRF Attack</h1>
	<form name="csrf_form" action="../Prototype5/" method="POST">
    <input type="hidden" name="csrf_param" value="POST_ATTACK">
  </form>

	<?php






	?>
</body>
</html>
