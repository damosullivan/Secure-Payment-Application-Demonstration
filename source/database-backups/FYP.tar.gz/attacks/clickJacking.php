<html>
  <head>
    <link type="text/css" href="clickJacking.css" rel="stylesheet" />
  </head>
  <body>
<div>
<iframe id="window" src="../Prototype4/home.php" ></iframe>
</div>

<p id="fakeLink" >CLICK ME!!!!</p>



  </body>
</html>


