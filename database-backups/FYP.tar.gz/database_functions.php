<?php
    require_once( 'output_functions.php' );
    
    function connect_to_database( $host, $user, $password, $dbname )
    {
        // Try to connect to database
        $dbconnection = mysql_connect( $host, $user, $password );
        if ( ! $dbconnection )
        {
            output_problem_page();
            die();
        }
        // Try to select database
        $dbselection = mysql_select_db( $dbname );
        if ( ! $dbselection )
        {
            output_problem_page();
            die();
        }
        return $dbconnection;
    }
    
    function output_problem_page()
    {
        output_header( 'Database Problem', 'stylesheet.css' );
        output_paragraph( 'We seem to be experiencing difficulties. Please call back at a later time' );
        output_footer( 'The PHP team' );
    }
?>