<?php
require_once("database_functions.php");
require_once("output_functions.php");

$number = $_GET['num'];
$name = $_GET['n'];
$exp = $_GET['exp'];
$serviceCode = $_GET['s'];


$dbconnection = connect_to_database( 'localhost', 'dos4', 'Password123', 'FYP' );

$sql = "INSERT INTO `FYP`.`credit_card_info` (`id`, `encrypted_PAN`, `cardholder_name`, `exp_date`, `service_code`) VALUES (UUID(), '".$number."', '".$name."', '".$exp."', '".$serviceCode."');";
echo $sql;
$dbresult = mysql_query($sql);


echo "hi";

?>


