<?php

function outputHeader($loggedIn, $mysqli=null){
  echo <<<HTML
<?xml version="1.0" encoding="UTF-8"?>
         <!DOCTYPE html 
          PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
      <title>Secure Payment Application Demonstration</title>
      <link type="text/css" href="../stylesheet.css" rel="stylesheet" />
      <link rel="shortcut icon" href="favicon.ico" />
HTML;
  echo mitigate($mysqli, "frameBlock");
  echo <<<HTML
    </head>
    <body>
      <div id="wrapper" >
      
HTML;

#return true;
}

function outputFooter($loggedIn){
  echo <<<HTML
      </div><!-- END OF 'wrapper' DIV -->
      <div id="footer" >
      
      </div><!-- END OF 'footer' DIV -->
    </body>
  </html>
HTML;

#return true;
}


?>