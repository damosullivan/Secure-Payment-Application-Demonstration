<html>
<head>
<title>VIEW</title>
</head>
<body>
<?php
require_once("database_functions.php");
require_once("output_functions.php");



$dbconnection = connect_to_database( 'localhost', 'dos4', 'Password123', 'FYP' );

$sql = "SELECT * FROM credit_card_info;";

$dbresult = mysql_query($sql);

echo "<table>";

while( $row = mysql_fetch_assoc($dbresult)) {
	echo "<tr>";
	foreach( $row as $key => $value){
		echo "<td></td><td>$value</td>";
	}
	echo "</tr>";
}

echo "</table>";



?>


</body>
</html>
